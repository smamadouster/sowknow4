-- SOWKNOW Knowledge Graph — PostgreSQL Migration
-- Run after your existing pgvector tables are in place.
-- ================================================================

-- ── Nodes ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS graph_nodes (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    canonical_name TEXT NOT NULL,
    aliases       TEXT[] DEFAULT '{}',
    node_type     TEXT NOT NULL,       -- values from NodeType enum
    language      TEXT DEFAULT 'fr',
    metadata      JSONB DEFAULT '{}',
    embedding     vector(1024),        -- pgvector, same model as RAG
    bucket        TEXT DEFAULT 'public' CHECK (bucket IN ('public', 'confidential')),
    created_at    TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_nodes_type        ON graph_nodes (node_type);
CREATE INDEX idx_nodes_bucket      ON graph_nodes (bucket);
CREATE INDEX idx_nodes_canonical   ON graph_nodes USING gin (to_tsvector('simple', canonical_name));
CREATE INDEX idx_nodes_aliases     ON graph_nodes USING gin (aliases);
CREATE INDEX idx_nodes_embedding   ON graph_nodes USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 50);


-- ── Edges ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS graph_edges (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id           UUID NOT NULL REFERENCES graph_nodes(id) ON DELETE CASCADE,
    target_id           UUID NOT NULL REFERENCES graph_nodes(id) ON DELETE CASCADE,
    edge_type           TEXT NOT NULL,
    confidence          REAL DEFAULT 0.5 CHECK (confidence BETWEEN 0 AND 1),
    extraction_method   TEXT NOT NULL,
    source_document_id  UUID,          -- FK to your documents table
    source_chunk_id     UUID,          -- FK to your chunks table
    metadata            JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ DEFAULT now(),

    -- prevent exact duplicate edges
    UNIQUE (source_id, target_id, edge_type, source_document_id)
);

CREATE INDEX idx_edges_source  ON graph_edges (source_id);
CREATE INDEX idx_edges_target  ON graph_edges (target_id);
CREATE INDEX idx_edges_type    ON graph_edges (edge_type);
CREATE INDEX idx_edges_conf    ON graph_edges (confidence);


-- ── Entity aliases (for fast resolution lookups) ─────────────────

CREATE TABLE IF NOT EXISTS entity_synonyms (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    surface_form  TEXT NOT NULL,        -- the string as it appeared in text
    canonical_id  UUID NOT NULL REFERENCES graph_nodes(id) ON DELETE CASCADE,
    language      TEXT DEFAULT 'fr',
    UNIQUE (surface_form, canonical_id)
);

CREATE INDEX idx_synonyms_surface ON entity_synonyms (surface_form);
