"""
SOWKNOW Knowledge Graph — Integration Example
===============================================
Shows how to wire the graph module into your existing
Celery task pipeline and Telegram/chat query flow.
"""

import asyncio
import asyncpg

from knowledge_graph import (
    ConnectionQuery,
    EntityExtractor,
    GraphTraversalService,
)


# ═══════════════════════════════════════════════════════════════════
# 1. CELERY TASK: Hook into your existing document processing pipeline
# ═══════════════════════════════════════════════════════════════════

# In your existing Celery task that chunks + embeds documents,
# add this AFTER the embedding step:

async def graph_extraction_step(
    chunk_text: str,
    document_id: str,
    chunk_id: str,
    bucket: str,
    pool: asyncpg.Pool,
):
    """
    Call this from your existing chunk-processing Celery task.
    Example: add to the end of your `process_document_task`.
    """
    from your_app.services.embedding import embed_text  # your existing fn
    from your_app.services.llm_router import route_llm_call  # your existing router

    async def embedding_fn(text: str) -> list[float]:
        return await embed_text(text)  # multilingual-e5-large

    async def llm_fn(prompt: str) -> str:
        # Use your existing LLM router — it already handles
        # Kimi 2.5 vs Ollama routing based on bucket
        return await route_llm_call(prompt, bucket=bucket)

    extractor = EntityExtractor(
        pool=pool,
        embedding_fn=embedding_fn,
        llm_fn=llm_fn,
        spacy_model="fr_core_news_lg",  # or "en_core_web_trf" based on doc language
    )

    stats = await extractor.process_chunk(
        chunk_text=chunk_text,
        document_id=document_id,
        chunk_id=chunk_id,
        bucket=bucket,
    )
    return stats


# ═══════════════════════════════════════════════════════════════════
# 2. QUERY HANDLER: "Find connections between X and Y"
# ═══════════════════════════════════════════════════════════════════

# Add this as a new intent in your AgentOrchestrator or as a
# standalone handler in your Telegram bot / chat system.

async def handle_connection_query(
    start_entity: str,
    end_entity: str,
    user_role: str,  # "admin", "super_user", "user"
    pool: asyncpg.Pool,
):
    """
    Handle queries like:
      "Is there a link between employee salary and annual turnover?"
      "What connects interest paid to the bank with our revenue?"
    """
    from your_app.services.embedding import embed_text

    service = GraphTraversalService(
        pool=pool,
        embedding_fn=embed_text,
    )

    query = ConnectionQuery(
        start_entity=start_entity,
        end_entity=end_entity,
        max_depth=5,
        min_confidence=0.3,
        include_confidential=(user_role in ("admin", "super_user")),
    )

    paths = await service.find_connections(query, max_results=5)

    if not paths:
        return (
            f"No connection found between '{start_entity}' and "
            f"'{end_entity}' within 5 hops. This could mean the "
            f"relationship hasn't been captured in your documents yet, "
            f"or the entities need different phrasing."
        )

    # Format for chat response
    lines = [
        f"Found {len(paths)} path(s) connecting "
        f"**{start_entity}** → **{end_entity}**:\n"
    ]
    for i, path in enumerate(paths, 1):
        lines.append(f"**Path {i}** ({path.hop_count} hops, "
                      f"confidence: {path.min_confidence:.0%}):")
        lines.append(f"  {path.summary}")
        if path.supporting_document_ids:
            lines.append(f"  📄 Sources: {len(path.supporting_document_ids)} document(s)")
        lines.append("")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════
# 3. NEIGHBOURHOOD QUERY: "Show me everything related to X"
# ═══════════════════════════════════════════════════════════════════

async def handle_explore_query(
    entity_name: str,
    user_role: str,
    pool: asyncpg.Pool,
):
    """
    Handle queries like:
      "What do we know about employee salaries?"
      "Show me everything connected to our balance sheet."
    """
    from your_app.services.embedding import embed_text

    service = GraphTraversalService(pool=pool, embedding_fn=embed_text)

    neighbours = await service.get_neighbours(
        entity_name,
        max_depth=2,
        include_confidential=(user_role in ("admin", "super_user")),
    )

    if not neighbours:
        return f"No graph data found for '{entity_name}'."

    # Group by node type
    grouped: dict[str, list] = {}
    for n in neighbours:
        t = n.get("node_type", "unknown")
        grouped.setdefault(t, []).append(n["canonical_name"])

    lines = [f"**Entities connected to '{entity_name}':**\n"]
    for node_type, names in grouped.items():
        lines.append(f"  __{node_type}__: {', '.join(names[:10])}")
        if len(names) > 10:
            lines.append(f"    ... and {len(names) - 10} more")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════
# 4. INTENT DETECTION: Wire into your AgentOrchestrator
# ═══════════════════════════════════════════════════════════════════

# In your orchestrator's intent parser, add detection for graph queries.
# These patterns indicate the user wants graph traversal, not just RAG:

GRAPH_INTENT_PATTERNS = [
    "is there a link between",
    "is there a connection between",
    "what connects",
    "how is .* related to",
    "path between",
    "relationship between",
    "show me everything related to",
    "show me everything connected to",
    "what do we know about",
    # French equivalents
    "y a-t-il un lien entre",
    "quel est le rapport entre",
    "qu'est-ce qui relie",
    "montre-moi tout ce qui concerne",
]
